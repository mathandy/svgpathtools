from __future__ import division, absolute_import, print_function
# import unittest
# try:
#     from ..bezier import *
# except ValueError:
#     from svgpathtools.bezier import *
#
#
# class Test_bezier(unittest.TestCase):
#     def test_bernstein(self):
#         self.fail()
#
#     def test_bezier_point(self):
#         self.fail()
#
#     def test_split_bezier(self):
#         self.fail()
#
#
# if __name__ == '__main__':
#     unittest.main()
